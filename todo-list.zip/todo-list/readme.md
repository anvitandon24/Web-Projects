# Todo List

# [Preview the site](https://alsiam.github.io/web-projects/todo-list)

![image info](../assets/images/todo-list.png)