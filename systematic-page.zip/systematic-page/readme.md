# Systematic Page

# [Preview the site](https://alsiam.github.io/web-projects/systematic-page)

![image info](../assets/images/systematic-page.png)